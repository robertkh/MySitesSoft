<?php
session_start();
$ss = $_SESSION["login"];
if(empty($ss))
    exit("]There is no active user. Please log in at first!");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
$sql = "SELECT id, word, pr, pos, translation, memo, dt, df, p, n, top FROM $ss order by word ";
//$sql = "SELECT id, word, pr, pos, translation, memo, dt, df, p, n, top FROM $ss WHERE word LIKE 't%' ";
$result = mysqli_query($conn, $sql);
$cnt_of_words = mysqli_num_rows($result);
if($cnt_of_words == 0)
    echo "]Your vocabulary is empty!";
else 
{
    $ar = "[";
    while($row = mysqli_fetch_assoc($result)) 
    {
            $ar .= '{"id":"'.addslashes( strip_tags($row["id"])).'",' ;
            $ar .= '"wd":"'.$row["word"].'",' ;
            $ar .= '"pr":"'.$row["pr"].'",' ;
            $ar .= '"ps":"'.$row["pos"].'",' ;
            $ar .= '"tr":"'.addslashes( strip_tags($row["translation"])).'",' ;
            $ar .= '"mm":"'.addslashes( trim( strip_tags($row["memo"]) )).'",' ;
            $ar .= '"dt":"'.$row["dt"].'",' ;
            $ar .= '"df":"'.$row["df"].'",' ;
            $ar .= '"tp":"'.$row["top"].'",' ;
            $ar .= '"p":"'.$row["p"].'",' ;
            $ar .= '"n":"'.$row["n"].'"},' ;   
            
    }
    echo chop($ar,",")."]";
        
    /* 
         $ar .= '{"id":"'.addslashes( strip_tags($row["id"])).'",' ;
            $ar .= '"word":"'.$row["word"].'",' ;
            $ar .= '"pr":"'.$row["pr"].'",' ;
            $ar .= '"pos":"'.$row["pos"].'",' ;
            $ar .= '"translation":"'.addslashes( strip_tags($row["translation"])).'",' ;
            $ar .= '"memo":"'.addslashes( trim( strip_tags($row["memo"]) )).'",' ;
            $ar .= '"df":"'.$row["df"].'",' ;
            $ar .= '"tp":"'.$row["dt"].'",' ;
            $ar .= '"top":"'.$row["top"].'",' ;
            $ar .= '"p":"'.$row["p"].'",' ;
            $ar .= '"n":"'.$row["n"].'"},' ;       
    */
    
   
}
//------------------------------------------------
mysqli_close($conn);
?>