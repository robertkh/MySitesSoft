<?php
$us = $_POST["login"];
if(empty($us)) exit("]The username input fild has not filled!");
$em = $_POST["email"];
if(empty($em)) exit("]The email input fild has not filled!");
$ps = $_POST["password"];
if(empty($ps)) exit("]The password input fild has not filled!");

if (is_numeric($us[0])) exit("]Usernames must begin with a letter!");
elseif ((strlen($us) < 3 || strlen($us) > 18)) exit("]Username must take 3 - 16 characters!");
else
{
    include_once 'conn.php';
    $sql = "SELECT * FROM users WHERE login = '$us' LIMIT 1";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) exit("]'$us' is taken, please try other one!");
} 
?>
<?php
if (!filter_var($em, FILTER_VALIDATE_EMAIL)) exit("]Invalid email format!");
else
{
    $sql = "SELECT * FROM users WHERE email = '$em' LIMIT 1";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) exit("This email is in use, please try other one!");
}
?>
<?php
if ((strlen($ps)< 3 || strlen($ps) >16)) exit("]The password must take 3 - 16 characters!"); 
?>
<?php
$sql = "INSERT INTO users (login, password, email) VALUES ('$us','$ps', '$em')";
if (!mysqli_query($conn, $sql))
    exit("Error: " . $sql . "<br>" . mysqli_error($conn));
else
{
    $sql_1 ="CREATE TABLE $us
    (
        id           int( 3 ) NOT NULL AUTO_INCREMENT ,
	word         varchar( 30 ) NOT NULL ,
        pr           varchar( 30 ) NOT NULL ,
	pos          varchar( 12 ) NOT NULL ,
	translation  varchar( 255 ) NOT NULL ,
	memo         text NOT NULL ,
	dt           timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP ,
	df           ENUM('0','1') NOT NULL DEFAULT '0',
        p            INT(3) NOT NULL DEFAULT '0' ,
        n            INT(3) NOT NULL DEFAULT '0' ,
        top           ENUM('0','1') NOT NULL DEFAULT '0',
        PRIMARY KEY ( `id` ) 
    )";
    if (!mysqli_query($conn, $sql_1))
    echo "Error: " . $sql_1 . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?> 
<?php
//$from = "noreply@tothis.mail";
$email = $em;
$subject = "Activate Account";
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: noreply@to_this_mail' . "\r\n";

$message = "
<html>
<head>
<title>HTML email</title>
</head>
<body>
<p> Dear <u> $us </u> click the link below to activate account!</p>
<a href = 'http://myvocabulary.dx.am/mobile/activ.php?a_code=$us'> Activate now </a>
</body>
</html>";

//mail($email, $subject, $message, "From:".$from);
mail($email, $subject, $message, $headers);

echo "|Succesfully Registration! Please check your mail, you have been sent your activation link.";
?>
<?php
/*$sql = " CREATE USER '$send_login'@'localhost'  IDENTIFIED BY 'newpass'";
$sql1 = "CREATE DATABASE IF NOT EXISTS ".$send_login;
$sql2 ="CREATE TABLE ".$send_login.".table_".$send_login."
(
id           int( 3 ) NOT NULL AUTO_INCREMENT ,
word         varchar( 20 ) NOT NULL ,
pos          varchar( 8 ) NOT NULL ,
translation  varchar( 30 ) NOT NULL ,
memo         text NOT NULL ,
dt           timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP ,
PRIMARY KEY ( `id` ) 
)";
$sql3 = "GRANT ALL PRIVILEGES ON ".$send_login.".* TO '$send_login'@'localhost'";*/
//$sql3 = " GRANT ALL PRIVILEGES ON *.* TO '$send_login'@'localhost'";
?>