<?php 
session_start();
$ss = $_SESSION["login"];
if(empty($ss)) exit("]There is no active user. Please log in at first!");
?>
<?php
$send_word = $_POST["id1"];
$pr = $_POST['pr'];
$send_pos = $_POST["id2"];
$send_translation = $_POST["id3"];
$send_memo = $_POST["id4"];
if(empty($send_word)) exit("]The necessary input field (word) has not filled!");
?>
<?php
include_once 'conn.php';
$send_memo = mysqli_real_escape_string($conn, $send_memo); 

$top = 'top1000';                 // ayspes ashxatum e, uxix` woch
$sql_1 = "SELECT word FROM $top WHERE word = '$send_word'";
$result_1 = mysqli_query($conn, $sql_1);
$cnt_of_words = mysqli_num_rows($result_1);
$t = 0;
if($cnt_of_words !== 0) $t=1;

$sql = "INSERT INTO $ss(word, pr, pos, translation, df, memo, top) 
	VALUES ('$send_word', '$pr', '$send_pos', '$send_translation', '1', '$send_memo', '$t')";
if (!mysqli_query($conn, $sql)) 
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
else
    echo "|The word has been added succesfully!";
mysqli_close($conn);
?> 
