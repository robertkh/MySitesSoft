<?php

$max = $_POST["max"];
$dict = $_POST["dict"];
include_once 'conn.php';
$dict = mysqli_real_escape_string($conn, $dict); 

$sql_1 = " UPDATE aaa SET max = '$max',memo = '$dict' ";
	$result=mysqli_query($conn, $sql_1);
	if ($result)
    	echo "|The dictionary has been saved succesfully!";
	else 
    	echo "Error updating record:" . mysqli_error($conn);

mysqli_close($conn);
?> 