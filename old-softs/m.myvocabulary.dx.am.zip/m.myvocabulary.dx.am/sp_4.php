<?php
session_start();
$ss = $_SESSION['login'];
//if(empty($ss)) exit("]There is no active user. Please log in at first !");
?>
<?php
$id = $_POST["id"];
$w = $_POST["word"];
//if( empty($id) or empty($w) ) exit("]The POST Is Empty. Please fill all filds.");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
$sql = "SELECT word FROM $ss WHERE id ='$id'";
$result = mysqli_query($conn, $sql);
$n_r = mysqli_num_rows($result);
if($n_r == 0) exit("]Your vocabulary is empty!");
$row = mysqli_fetch_assoc($result);
$str1 = strtolower( trim($w) ); 
$str2 = strtolower( trim($row['word']) ); 
if(strcmp($str1,$str2)==0)
{
	$sql = "SELECT p FROM $ss WHERE id ='$id'";
	$result = mysqli_query($conn, $sql);
	$n_r = mysqli_num_rows($result);
	if($n_r == 0) die("]Your vocabulary is empty!");
	$row = mysqli_fetch_assoc($result);
	$p = $row['p']+1;
	$sql ="UPDATE $ss SET p = $p WHERE id ='$id'";
	if (!mysqli_query($conn, $sql)) die("]Error updating record:" . mysqli_error($conn)); 
    $b = 1;
    echo '["'.$str2.'",'.$p.','.$b.']'; 
}
else
{
	$sql = "SELECT n FROM $ss WHERE id ='$id'";
	$result = mysqli_query($conn, $sql);
	$n_r = mysqli_num_rows($result);
	if($n_r == 0) die("]Your vocabulary is empty!");
	$row = mysqli_fetch_assoc($result);
	$n = $row['n']+1;
	$sql ="UPDATE $ss SET n = $n WHERE id ='$id'";
	if (!mysqli_query($conn, $sql)) die("]Error updating record:" . mysqli_error($conn));
    $b = 0;
    echo '["'.$str2.'",'.$n.','.$b.']';
}
//------------------------------------------------
mysqli_close($conn);
?>