<?php
session_start();
$ss = $_SESSION['login'];
if(empty($ss)) exit("]There is no active user. Please log in at first"); 

$f = $_POST["select"];
if( empty($f)) exit("]The select fild Is empty!"); 
?>

<?php
include_once 'conn.php';
if($f == 'all')
    $sql = "SELECT translation,p,n FROM $ss LIMIT 1";
else 
    $sql = "SELECT translation,p,n FROM $ss WHERE df = '1' LIMIT 1";

$result = mysqli_query($conn, $sql); 
if(!$result) exit(']Your vocabulary is empty!');// straxovka bool-ic
$n_r = mysqli_num_rows($result);
if($n_r == 0) exit("]Your vocabulary is empty!");
$row = mysqli_fetch_assoc($result);
$ar = '["'.$row['translation'].'",'.$row['p'].','.$row['n'].','; // json-um ""
//------------------------------------------------
if($f == 'all')
    $sql = "SELECT id FROM $ss";
else 
    $sql = "SELECT id FROM $ss WHERE df = '1'";
$result = mysqli_query($conn, $sql);
while($row = mysqli_fetch_assoc($result))
    {
        $ar .=$row['id'].=',';
    } 
echo chop($ar,",")."]";              // !!!hanum a, bayc save chi anum      
mysqli_close($conn);
?>