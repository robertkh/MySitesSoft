<?php
session_start();
$ss = $_SESSION['login'];
//if(empty($ss)) exit("]There is no active user. Please log in at first !");
?>
<?php
$id = $_POST["id"];
//$f = $_POST["select"];
//if( empty($id) or empty($f)) exit("]The POST Is Empty. Please fill all filds.");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
//if($f == 'all') 
$sql = "SELECT word FROM $ss WHERE id ='$id'";
//else $sql = "SELECT word FROM $ss WHERE df = '1' AND id ='$id'";

$result = mysqli_query($conn, $sql);
$n_r = mysqli_num_rows($result);
if($n_r == 0) exit("]Your vocabulary is empty!");
$row = mysqli_fetch_assoc($result);
$str = strtolower( trim($row['word'])); 
$l = strlen(trim($str));
echo $str[0];
for($k = 1; $k < $l; $k++) 	echo '*'; 
//------------------------------------------------
mysqli_close($conn);
?>