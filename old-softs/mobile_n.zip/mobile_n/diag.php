<?php
session_start();
$ss = $_SESSION["login"];
if(empty($ss))
    exit("]There is no active user. Please log in at first!");
?>
<?php
//--------------------------
include_once 'conn.php';
//--------------------------
?>
<?php
$max = 0;
for($ch_n = 97; $ch_n < 123; $ch_n++)
{
  $sql = "SELECT word FROM $ss where word like '".chr($ch_n)."%' ";
  $result = mysqli_query($conn, $sql);
  $cnt_of_words = mysqli_num_rows($result);
  if($cnt_of_words > $max)
           $max = $cnt_of_words.'|||';
}
if($max == 0) exit("]Vocabulary is empty!");
?>
<?php
     $sql = "SELECT word FROM $ss";
     $result = mysqli_query($conn, $sql);
     $num_of_words = mysqli_num_rows($result);
     echo  $num_of_words.'|||';

?>
<?php
echo  "
      <table id ='diag_table' style='width:100%'>
          <thead><tr>";
for($ch_n = 97; $ch_n < 123; $ch_n++)
{
  $sql = "SELECT word FROM ".$ss." where word like '".chr($ch_n)."%'";
  $result = mysqli_query($conn, $sql);
  $cnt_of_words = mysqli_num_rows($result);
  echo "<th id = 'img'><img src = 'img/poll.gif' height ='".$cnt_of_words*240/$max."px' width = '7px'></th>";
}
  echo  "</tr> </thead>
        <tbody><tr>";
            for($ch_n = 97; $ch_n < 123; $ch_n++)
              echo "<td>".chr($ch_n)."</td>";
  echo "</tr></tbody></table>";
//------------------------------------------------------------
mysqli_close($conn);
?>