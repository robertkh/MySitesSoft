<?php
session_start();
$ss = $_SESSION["login"];
if(empty($ss))
    exit("]There is no active user. Please log in at first!");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
$sql = "SELECT id, word, pr, pos, translation, memo, dt, df, p, n, top FROM $ss order by word";
$result = mysqli_query($conn, $sql);
$cnt_of_words = mysqli_num_rows($result);
if($cnt_of_words == 0)
    echo "]Your vocabulary is empty!";
else 
{
    $ar = "[";
    while($row = mysqli_fetch_assoc($result)) 
    {
            $ar .= '{"id":"'.addslashes( strip_tags($row["id"])).'",' ;
            $ar .= '"wd":"'.$row["word"].'",' ;
            $ar .= '"pr":"'.$row["pr"].'",' ;
            $ar .= '"ps":"'.$row["pos"].'",' ;
            $ar .= '"tr":"'.addslashes( strip_tags($row["translation"])).'",' ;
            $ar .= '"mm":"'.addslashes( trim( strip_tags($row["memo"]) )).'",' ;
            $ar .= '"dt":"'.$row["dt"].'",' ;
            $ar .= '"df":"'.$row["df"].'",' ;
            $ar .= '"tp":"'.$row["top"].'",' ;
            $ar .= '"p":"'.$row["p"].'",' ;
            $ar .= '"n":"'.$row["n"].'"},' ;       
    }
    echo chop($ar,",")."]";
        
    /* 
    $top = 'top1000';
    while($row = mysqli_fetch_assoc($result)) 
    {
       $w = $row['word'];
       $idd = $row['id'];
       $sql_1 = "SELECT word FROM $top WHERE word = '$w'";
       $result_1 = mysqli_query($conn, $sql_1);
       $cnt_of_words = mysqli_num_rows($result_1);
       $t = 0;
       if($cnt_of_words !== 0) $t=1;
       $sql ="UPDATE $ss SET top = '$t' WHERE id ='$idd' ";
       $result_2=mysqli_query($conn, $sql);
       if (!$result_2)
             echo "]T??????????";
    }  
    */
    
    /* 
     $ar='';
     while($row = mysqli_fetch_assoc($result)) 
     {
             $ar .= $row["id"].'|';
             $ar .= $row["word"].'|';
             if($row["pr"] == null) $ar .= 'empty_fild|';
             else $ar .= $row["pr"].'|';
             if($row["pos"] == null) $ar .= 'empty_fild|';
             else $ar .= $row["pos"].'|';
             if($row["translation"] == null) $ar .= 'empty_fild|';
             else $ar .= $row["translation"].'|';
             if($row["memo"] == null) $ar .= 'empty_fild|';
             else $ar .= $row["memo"].'|';
             $ar .= $row["dt"].'|';
             $ar .= $row["df"].'|';
             $ar .= $row["p"].'|';
             $ar .= $row["n"].'|';
             $ar .= $row["top"].'|||';
             
     
     } 
     echo chop($ar,'|||'); 
     */
}
//------------------------------------------------
mysqli_close($conn);
?>