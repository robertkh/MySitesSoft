<?php
session_start();
$ss = $_SESSION["login"];
//---------------------------------------------------------------------------
$w = getenv('REMOTE_ADDR');
include_once 'conn.php';
//$sql = "INSERT INTO mu(w) VALUES ('$w')";
$sql = "INSERT INTO mu(w,m) VALUES ('$w', '1')";
if (!mysqli_query($conn, $sql)) 
	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
//---------------------------------------------------------------------------
if(empty($ss))
	echo "No User";
else
	echo $ss;
?> 