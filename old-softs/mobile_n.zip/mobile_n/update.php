<?php
session_start();
$ss = $_SESSION["login"];
if(empty($ss)) exit("]There is no active user. Please log in at first!");
?>
<?php
$send_id = $_POST["id"];
$up_pr = $_POST['up_pr'];
$send_pos = $_POST["pos"];
$send_translation = $_POST["translation"];
$send_memo = trim( $_POST["memo"] );
$send_memo = strip_tags(addslashes($send_memo));
if(empty($send_id)) exit("]The id of word is undefined!");
?>
<?php
include_once 'conn.php';
$sql ="UPDATE $ss SET pr = '$up_pr', pos ='$send_pos',translation ='$send_translation', memo = '$send_memo' WHERE id ='$send_id'";
$result=mysqli_query($conn, $sql);
if ($result)
   echo "|The word has been updated succesfully!";
else 
   echo "Error updating record:" . mysqli_error($conn);
mysqli_close($conn);
?>