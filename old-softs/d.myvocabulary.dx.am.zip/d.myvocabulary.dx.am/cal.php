<?php
$m = $_POST["m"];
$d = $_POST["a_t"];
if(empty($m))
{
	$d = date('1-M-Y');
	$dd = date_create($d);
}
elseif ($m == 1) 
{
	$dd = date_create($d);
	date_add($dd,date_interval_create_from_date_string("1 month"));
}
else
{
	$dd = date_create($d);
	date_add($dd,date_interval_create_from_date_string("-1 month"));
}
//------------------------------------------------------------------------
calendar($dd);
function calendar($d)
{
	$sh_or = date_format($d,"w");  
	$a_t = date_format($d,"M-Y");
	$am_or = date_format($d,"j");            // kareli er skasel 1-ic u verj
	$am_max_or = date_format($d,"t");
	if($sh_or == 0) $sh_or = 7;
	echo 	"<div id = 'calendar'>";
	echo "<a href='#'class ='cancel' onclick = 'clear_par()'>&times;</a>";
	echo "<table>";
	echo "<caption><a href='#'onclick = 'cal_l()'><i class='fa fa-chevron-left' style='font-size:18px'></i></a><span id = 'cap'>".$a_t."</span><a href='#' onclick = 'cal_r()'><i class='fa fa-chevron-right' style='font-size:18px'></i></a></caption>";
	echo 	"<tr>
						<th>Mn</th> 
						<th>Th</th>
						<th>Wd</th>
						<th>Tr</th> 
						<th>Fr</th>
						<th style='color:#e63900'>St</th>
						<th style='color:#e63900'>Sn</th>
			</tr>";
	echo 	"<tbody><tr>";
						for($i=1;$i<=7;$i++)
						{
							if($i<$sh_or) echo	"<td></td>";
							elseif (date('j') == $am_or and date('M-Y')==$a_t) 
							{
								echo "<td><a href='#' id = 'today' onclick = 'rrr(this)'>".$am_or++."</a> </td>";
							}
							else
							{
								echo "<td><a href='#' onclick = 'rrr(this)'>".$am_or++."</a> </td>";
							}
						}
	echo 	"</tr>";
						for($j=0 ; $j < 5 and $am_or <= $am_max_or ; $j++)
						{
							echo 	"<tr>";
							for($i = 0 ; $i < 7 ; $i++)
							{
								if($am_or <= $am_max_or)
									if(date('j') == $am_or and date('M-Y')==$a_t)
									{
										echo "<td><a href='#' id = 'today' onclick = 'rrr(this)'>".$am_or++."</a> </td>";
									}
									else
										echo "<td><a href='#'onclick = 'rrr(this)'>".$am_or++."</a> </td>";
								else
									echo	"<td></td>";		
							}
							echo 	"</tr>";
						}
	echo "</tbody></div>";
}
//------------------------------------------------------------------------
/*function calendar($d)
{
	$sh_or = date_format($d,"w");  
	$a_t = date_format($d,"M-Y");
	$am_or = date_format($d,"j");            // kareli er skasel 1-ic u verj
	$am_max_or = date_format($d,"t");
	if($sh_or == 0) $sh_or = 7;
	echo 	"<div class = 'calendar'>";
	echo "<a href='#'class ='cancel' onclick = 'clear_par()'>x</a>";
	echo  "<a href = '#' onclick = 'cal_l()'><img src = 'img/left.png' id = 'img1'></a>";
	echo  "<a href = '#' onclick = 'cal_r()'><img src = 'img/rigth.png' id = 'img2'></a>";
	echo 	"<table>";
	echo 	"<caption id = 'cap'>".$a_t."</caption>";
	echo 	"<tr>
						<th>Mn</th>
						<th>Th</th>
						<th>Wd</th>
						<th>Tr</th> 
						<th>Fr</th>
						<th style='color:#e63900'>St</th>
						<th style='color:#e63900'>Sn</th>
				</tr>";
	echo 	"<tr>";
						for($i=1;$i<=7;$i++)
						{
							if($i<$sh_or) echo	"<td></td>";
							elseif (date('j') == $am_or and date('M-Y')==$a_t) 
							{
								echo "<td><a href='#' id = 'today' onclick = 'rrr(this)'>".$am_or++."</a> </td>";
							}
							else
							{
								echo "<td><a href='#' onclick = 'rrr(this)'>".$am_or++."</a> </td>";
							}
						}
	echo 	"</tr>";
						for($j=0 ; $j < 5 and $am_or <= $am_max_or ; $j++)
						{
							echo 	"<tr>";
							for($i = 0 ; $i < 7 ; $i++)
							{
								if($am_or <= $am_max_or)
									if(date('j') == $am_or and date('M-Y')==$a_t)
									{
										echo "<td><a href='#' id = 'today' onclick = 'rrr(this)'>".$am_or++."</a> </td>";
									}
									else
										echo "<td><a href='#'onclick = 'rrr(this)'>".$am_or++."</a> </td>";
								else
									echo	"<td></td>";		
							}
							echo 	"</tr>";
						}
	echo "</div>";
}*/
?>