<!DOCTYPE html>
<html>
<head>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script type = "text/javascript" src = "js/myscript2.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset='utf8'>
	<link rel="stylesheet" href="css/w3.css">
</head> 
<body>
	<div class="w3-card-4" style="width:500px; position: absolute; left:200px; top:150px;" id = 'mess'>
		<div class="w3-container w3-brown">
			<span onclick="$('#mess').hide()" class="w3-closebtn w3-large w3-padding-top w3-text-white">&times;</span>
		  	<h2>Message Text</h2>
		</div>
		<form class="w3-container" id = 'rrr'>
			<p><textarea class="w3-input w3-padding-rigth w3-pale-yellow" style="resize:none" id = 'mess_text' autofocus ></textarea></p>
			<p><input type = 'button' value="Send" class="w3-btn w3-brown" onclick="mess()"></p>
		</form>
	</div>

	<div id="alert" class="w3-modal">
	    <div id = 'alert_1' class="w3-modal-content w3-card-4" style="width:400px;">
	        <header class="w3-container" id='al_head'> 
	                <span onclick="$('#alert').hide()" class="w3-closebtn w3-padding-top w3-large">&times;</span>
	                <h4>Message from My<i>Vocabulary</i> :</h4>
	        </header>
	        <div id="message" class="w3-large w3-padding-large w3-small"></div>
	    </div>
	</div>
</body>

</html> 
