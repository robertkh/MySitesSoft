<?php
$ps = $_POST['ps'];
if(empty($ps))
	exit;
elseif ((strlen($ps) < 3 || strlen($ps) > 16)) 
    exit("<strong  style='color:#F00'>3 - 16 characters please.</strong >"); 
echo "OK";
?>