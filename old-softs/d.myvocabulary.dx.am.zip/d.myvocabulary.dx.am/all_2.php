<?php
session_start();
$ss = $_SESSION["login"];
if(empty($ss))
    exit("]There is no active user. Please log in at first!");
?>
<?php
$n = strip_tags(addslashes($_POST["id"]));
$t = $_POST["j"];
if( empty($n) or empty($t) )
    exit("]The necessary input fild(s) has not filled!");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
$sql = "SELECT word, translation, memo FROM $ss WHERE id = $n";
$result = mysqli_query($conn, $sql);
$r_n = mysqli_num_rows($result);
if($r_n == 0)
    echo "]Your vocabulary is empty";
else 
{             
    $row = mysqli_fetch_assoc($result);
    if($t==5) 
    {
        $s1 = "<mark>" .$row['word']. "</mark>";
        $s2 = str_replace($row['word'],$s1, $row['memo']);
        echo  $s2; 
    }
    elseif ($t == 4) 
        echo $row['translation']; 
}
//------------------------------------------------
mysqli_close($conn);
?>