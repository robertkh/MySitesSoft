<?php
session_start();
$ss = $_SESSION['login'];
if(empty($ss))
    exit("]There is no active user. Please log in at first!");
?>
<?php
$send_id = strip_tags($_POST["id"]);
if( empty($send_id) )
    exit("]The necessary input fild(s) has not filled!");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
$sql = "SELECT df FROM $ss WHERE id = $send_id";
$result = mysqli_query($conn, $sql);
$cnt_of_words = mysqli_num_rows($result);
if($cnt_of_words == 0) echo "} Your vocabulary is empty.";
else  $row = mysqli_fetch_assoc($result);
if($row['df'] == 0)
{
    $sql ="UPDATE $ss SET df = '1' WHERE id =".$send_id;
    if (mysqli_query($conn, $sql)) 
		echo    "|The word has been added to the favorite list!";
}
else 
{
    echo    "]The word was in the favorite list already!";
}
//------------------------------------------------------
mysqli_close($conn);
?>