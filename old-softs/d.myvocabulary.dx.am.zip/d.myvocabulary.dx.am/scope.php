<?php
session_start();
$t_name =$_SESSION["login"];
if(empty($t_name))
    exit("]There is no active user. Please log in at first!");
?>
<?php
$f = $_POST["first"];
$t = $_POST["second"];
if( empty($f) or empty($t) )
    exit("]The necessary input fild(s) has not filled!");
if($f > $t)
    exit("]The scope is wrong. Check it, please!");
?>
<?php 
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
$sql = "SELECT id, word, pos, translation, memo, df FROM $t_name
       where (word between '" .$f. "' and '" .$t. "') or (word like '".$t."%') order by word";   
$result = mysqli_query($conn, $sql);
$cnt_of_words = mysqli_num_rows($result);
echo "<h2>Count of words is $cnt_of_words</h2>";
if ($cnt_of_words > 0) 
{
    echo "<table id ='myTable'>
            <tr>
                <th class = 'c1'><i class='fa fa-check' style='font-size:14px'></i></th>
                <th class = 'c2'>Id#</th>
                <th class = 'c3'>Word</th>
                <th class = 'c4'>Pos</th>
                <th class = 'c5' Translation </th>
                <th> E x a m p l e </th>
            </tr>";
    while($row = mysqli_fetch_assoc($result)) 
    {
        if($row['df'] == 0)
            $id = "<span style='color:#0c0'>" .$row['id']. "</span>";
        else 
            $id = "<span style='color:red'>" .$row['id']. "</span>";
        echo "<tr>";
        echo "<td><input type = 'checkbox' name = 'a' /*onclick ='if(this.checked)
        { find_row() }' */</td>";
        echo "<td>" . $id . "</td>";
        echo "<td>" . $row["word"] . "</td>";
        echo "<td>" . $row["pos"]  . "</td>";
        echo "<td>" . $row["translation"]. "</td>";
        // sksum e f-n
        $s1 = "<mark>". $row["word"]."</mark>";
        $s2 = str_replace($row["word"],$s1, $row["memo"]);
        // avart
        echo "<td>" . $s2 . "</td>"; 
        echo "</tr>";
    }
    echo "</table>";
} 
//---------------------------------------------------------------
mysqli_close($conn);
?>