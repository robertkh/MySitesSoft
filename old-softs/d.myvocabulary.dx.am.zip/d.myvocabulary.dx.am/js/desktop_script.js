//---------------------    $.ajax()
var s = function(r)
{
	r = r.trim();
	if(r[0]=='|') { r = r.slice(1); panel(r); }
	else if(r[0]==']') { r = r.slice(1); my_alert(r, 'w3-red'); }
	else if(r[0]=='}') { r = r.slice(1); my_alert(r); }
	else $('#par').html(r);
}
var s_who = function(r)
{
	r = r.trim();
	if(r[0]=='|') { r = r.slice(1); my_alert(r, 'w3-green'); }
	else if(r[0]==']') { r = r.slice(1); my_alert(r, 'w3-red'); }
	else if(r[0]=='}') { r = r.slice(1); my_alert(r); }
	else $('#who').text(r);
}
var s_ust = function(r)
{
	r = r.trim();
	if(r[0]=='|') { r = r.slice(1); my_alert(r, 'w3-green'); }
	else if(r[0]==']') { r = r.slice(1); my_alert(r, 'w3-red'); }
	else if(r[0]=='}') { r = r.slice(1); my_alert(r); }
	else $('#ust').html(r);
}
var s_est = function(r)
{
	r = r.trim();
	if(r[0]=='|') { r = r.slice(1); my_alert(r, 'w3-green'); }
	else if(r[0]==']') { r = r.slice(1); my_alert(r, 'w3-red'); }
	else if(r[0]=='}') { r = r.slice(1); my_alert(r); }
	else $('#est').html(r);
}
var s_pst = function(r)
{
	r = r.trim();
	if(r[0]=='|') { r = r.slice(1); my_alert(r, 'w3-green'); }
	else if(r[0]==']') { r = r.slice(1); my_alert(r, 'w3-red'); }
	else if(r[0]=='}') { r = r.slice(1); my_alert(r); }
	else $('#pst').html(r);
}
var s_tbl = function(r)
{
	r = r.trim();
	if(r[0]=='|') { r = r.slice(1); my_alert(r, 'w3-green'); }
	else if(r[0]==']') { r = r.slice(1); my_alert(r, 'w3-red'); }
	else if(r[0]=='}') { r = r.slice(1); my_alert(r); }
	else El('myTable').rows[i].cells[j].innerHTML=r;
}

var e = function(x,y,z) {my_alert("An error occured: " + x.status + " " + x.statusText+" "+y+" "+z);};
var start = function () { $("#wait").css("display", "block");}
var end = function() {  $("#wait").css("display", "none");}
function serv_cn(url_of_php, send_var, s_f, e_f)
{ 
	var ajaxOptions = {
	  	url: url_of_php,
	  	data: send_var,
	  	type: "POST",
	  	beforeSend:start,
	  	complete:end,
	  	success: s_f,
	  	error: e_f
	};
	$.ajax(ajaxOptions);
}
//----------------------  V O C A B U L A R Y   -------------------------
function vocab()
{
	$('#n_w_f').hide();
	var send_var = "n_search=" + $("#id_search").val();
	serv_cn('vocab.php', send_var, s, e );
}
//------------------------- MacMil Lingvo  Wiki Google ---------------------------
function MacMil() 
{
	var loc_str = "http://www.macmillandictionary.com/dictionary/british/" + $("#id_search").val();
	var w = window.open();
	w.location.assign(loc_str);
}
function Lingvo() 
{ 
	var loc_str = "http://www.lingvo-online.ru/en/Translate/en-ru/" + $("#id_search").val();
	var w = window.open();
	w.location.assign(loc_str);
}
function Wiki() 
{
	var loc_str= "https://en.wikipedia.org/wiki/" + $("#id_search").val(); 
	var w = window.open();
	w.location.assign(loc_str);
}
function Google() 
{ 
	var loc_str = "https://www.google.com/search?q=" + $("#id_search").val() + "&ie=utf-8&oe=utf-8" ;
	var w = window.open();
	w.location.assign(loc_str);
}
//--------------------------  E L E M E N T N E R  -------------------------------
function panel(s)
{
	$('#panel span').html(s);
	$('#panel').slideDown();
	$('#panel').delay(5000).slideUp();
	//setTimeout(function(){$('#panel').slideUp();}, 5000);
}
function El(x) { return document.getElementById(x); }
//--------------------------  C L E A R  ---------------------------------------------------------
function clear_par() { 	$('#par').text(''); }
function clear_n_w_f() { $('#id1').val(''); $('#id3').val(''); $('#id4').val(''); }
function clear_u_w_f()
{
	$('#id_id').val('');
	$('#id_word').val('');
	$('#id_pos').val('');
	$('#id_trans').val('');
	$('#id_ex').val('');
}
function clear_reg()
{
	$("#id_user2").val("");
	$("#id_email").val("");
	$("#id_psw2").val("");
	$("#ust").text("");
	$("#est").text("");
	$("#pst").text("");
}
function clear_log()
{
	$('#id_user1').val('');
	$('#id_psw1').val('');
}
function clear_frg() { $('#id_email2').val(''); }
function clear_ch_psw()
{
	$('#id_chp').val('');
	$('#id_old').val('');
	$('#id_new').val('');
}
//---------------------   A L E R T ----------------------------------------
function my_alert (mess, color ='w3-blue')
{
	var w3_class = 'w3-container '+color;
	$('#alert').show();
	$('#message').text(mess);
	$('#al_head').attr('class', w3_class);
}
//--------------------------- S H O W and H I D E  ----------------------------------------------
function hide_all_form()
{
	$('#n_w_f').hide();
	$('#u_w_f').hide();
	$('#scope_f').hide();
	$('#reg_f').hide();
	$('#log_f').hide();
	$('#frg_psw').hide();
	$('#ch_psw').hide();
	$('#f_sp').hide();
}
//-------------------------  Who Am I  ------------------------------------------------------------
function who()
{
    if(screen.availWidth < 1024 ) 
        my_alert('Your screen width is small, please take wide screen device.');
	// kentronum a dnum, bayc w3-ov kareli e anel.
	var w = window.innerWidth; 
	var x = (w-1017)/2; w=x+'px';
	El("bd").style.left = w;
	serv_cn('who.php', null, s_who, e)
}
//-----------------------  F I N D index for Update and ... ----------------------------------------
function find_row()
{
	var i = 0;
	var t = document.getElementsByName("a");
	var l = t.length;
	for(i=0; i<l; i++) if(t[i].checked) return i;
}
function move_index_to_buffer() 
{ 
	hide_all_form();
	clear_u_w_f();
	var r = find_row();
	if(r===undefined) my_alert('You must select the word!', 'w3-red');		
	else
	{
		El("id_id").value = El("myTable").rows[r+1].cells[1].innerHTML;
		El("id_word").value = El("myTable").rows[r+1].cells[2].innerHTML;
		El("id_pos").value = El("myTable").rows[r+1].cells[3].innerHTML;
		El("id_trans").value = El("myTable").rows[r+1].cells[4].innerHTML;
		El("id_ex").value = El("myTable").rows[r+1].cells[5].innerHTML;		
		clear_par(); // !!! heracnum e table, hetn el nra infon
		$('#u_w_f').show();
	}	
}
//--------------------------  A D D function  ----------------------------------------------------
function add_start()
{
	if( $('#who').val().trim() == 'No User' ) { my_alert('There is no active user. Please log in at first!', 'w3-red');exit();}
	hide_all_form();
	clear_par();
	clear_n_w_f();
	$('#n_w_f').show();
}
function add() 
{
	var send_var = "id1=" + $("#id1").val();
	send_var += "&id2=" + $("#id2").val();
	send_var += "&id3=" + $("#id3").val();
	send_var += "&id4=" + $("#id4").val();
	serv_cn('add.php', send_var, s, e);
	$('#n_w_f').hide();
}
//-----------------------  D E L function  -------------------------------------------------------
function del()
{
	hide_all_form();
	var r = find_row();
	if(r===undefined)
		my_alert('You must select the element.', 'w3-red');
	else
	{
		var tab = document.getElementById("myTable");
		var send_var = "id=" + tab.rows[r+1].cells[1].innerHTML;
		serv_cn('del.php', send_var, s, e);
	}
	clear_par();
}
//-----------------------  U P D A T E  function  -------------------------------------------------
function update() 
{
	$('#u_w_f').hide();
	var send_var = "id=" + $("#id_id").val() +"&";
	send_var += "word=" + $("#id_word").val() +"&";
	send_var += "pos=" + $("#id_pos").val() +"&";
	send_var += "translation=" + $("#id_trans").val() +"&";
	send_var += "memo=" + $("#id_ex").val();
	serv_cn('update.php', send_var, s, e );
}
//---------------------   Add To Df     -----------------------------------------------------------
function add_to_df()
{
	var r = find_row();
	if(r != null)
	{
		var id = El("myTable").rows[r+1].cells[1].innerHTML;
		var send_var = 'id='+id;
		serv_cn('all_5.php', send_var, s, e);
	}
	else my_alert('You should select the word!', 'w3-red');
}
//---------------------------------------------------------------------------------------------
function lookup()
{
	var x = $('#select_2').val();
	if(x == 'all')
		all_word();
	else if(x=='scope')
		scope_1();
	else if(x=='date')
		cal();
	else
		diag();
}
//---------------------  Lookup A L L  ------------------------------------------------------------
function all_word()
{
	hide_all_form();
	serv_cn('all.php', null, s, e);
}
//----------------------  Lookup S C O P E  -------------------------------------------------------
function scope_1()
{
	if($('#who').val().trim() == 'No User') { my_alert('There is no active user. Please log in at first!', 'w3-red');exit();}
	clear_par();
	hide_all_form();
	$('#scope_f').show();
}
function scope_2()
{
	$('#scope_f').hide();
	var x1 = "first=" + $("#id_fr").val() +"&";
	var x2 = "second=" + $("#id_to").val();
	var send_var = x1+x2;
	serv_cn('scope.php', send_var, s, e);
}
//-------------------------  D A T A  ------------------------------
function cal()
{
	hide_all_form();
	serv_cn('cal.php', null, s, e);
}
function cal_r()
{
		var send_var ="m=1&a_t=1-" + $('#cap').text();
		serv_cn('cal.php', send_var, s, e);
}
function cal_l()
{
		var send_var ="m=-1&a_t=1-" + $('#cap').text();
		serv_cn('cal.php', send_var, s, e);
}
//--------------
function rrr(x)
{
	var d = x.innerHTML + '-' + $('#cap').text();
	var send_var = 'o_a_t='+d;
	serv_cn('cal_1.php', send_var, s, e);
}
//---------------------  D I A G R A M M A ----------------------------
function diag()
{
	hide_all_form();
	serv_cn('diag.php', null, s, e);
}
//---------------------- Create new user  -----------------------------
function reg()
{
	clear_par();
	hide_all_form();
	clear_reg();
	$('#reg_f').show();
}
function create_new_user()
{
	if(($('#ust').text() == 'OK') && ($('#est').text() == 'OK') && ($('#pst').text() == 'OK') )
	{
		var username = $("#id_user2").val();
		var psw = $("#id_psw2").val();
		var email = $("#id_email").val();
		var send_var = "login="+username+"&password="+psw+"&email="+email;
		serv_cn('reg.php', send_var, s, e);
		$('#reg_f').hide();
	}
	else
	{
		$('#bst').text('Fill out all data of the form!');	
		setTimeout(r,3000);	
	}
}
function r() { $('#bst').text(''); }
//--------------------------------------------------
function restrict(el_id)
{
	var rx = new RegExp;
	if(el_id == "id_user2") rx = /[^a-z0-9_]/gi;
	if(el_id == "id_psw2") 	rx = /[^a-z0-9]/gi;
	El(el_id).value = El(el_id).value.replace(rx, ""); 
}
//---------------------------------------------------
function checkun()
{
	restrict('id_user2');
	var us = $('#id_user2').val();
	if(us != "") $('#ust').text('checking...'); 
	var send_var = "u="+us;
	serv_cn('check_reg.php', send_var, s_ust, e);
}
function checkemail()
{
	var em = $('#id_email').val();
	if(em != "") $('#est').text('checking...');
	var send_var = "em="+em;
	serv_cn('check_email.php', send_var, s_est, e);
}
function checkpsw()
{
	restrict('id_psw2');
	var ps = $('#id_psw2').val();
	if(ps!= "") $('#pst').text('checking...');
	var send_var = "ps="+ps;
	serv_cn('check_psw.php', send_var, s_pst, e); 
}
//------------------------  L O G I N  ------------------------------------
function log()
{
	clear_par();
	hide_all_form();
	clear_log();
	$('#log_f').show();
}
var s_log_in = function(r)
{
	r = r.trim();
	if(r[0]=='|') 
	{ 
		r = r.slice(1); 
		$('#who').text(r); 
		panel('Velcome to MyVocabulary!');
   	}
	else if(r[0]==']') { r = r.slice(1); my_alert(r, 'w3-red'); }
	else { r = r.slice(1); my_alert(r); }
}
function log_in() 
{
	var username = $("#id_user1").val();
	var psw = $("#id_psw1").val();
	var send_var = "login="+username+"&password="+psw;
	serv_cn("log_in.php", send_var, s_log_in, e);
	$('#log_f').hide();
}
//-------------------------  R E K L A M M A  -----------------------------------------------------
var st;  
var ri = 0;
function fv() { return ri=++ri%3; }
function startPlayback() 
{  
	var u = 'url("img/dil'+fv()+'.jpg")';
	$('#main').css("background-image", u);
	st = setTimeout(startPlayback, 3000);
}
function hide_col()
{
	$('#col').hide();
	$('#main').css( "backgroundImage",'none');
	clearTimeout(st);
}
startPlayback();
//-------------------------  E M A I L _P S W  ---------------------------------------------------
function frg()
{
	clear_par();
	hide_all_form();
	clear_frg();
	$('#frg_psw').show();
}
function em_psw()
{
	var send_var = "email=" + $("#id_email2").val();
	serv_cn('email_psw.php', send_var, s, e);
	$('#frg_psw').hide();
}
//-----------------------  C H A N G E - psw  ---------------------------------------------------
function ch_psw1()
{
	clear_par();
	hide_all_form();
	clear_ch_psw();
	$('#ch_psw').show();
}
function ch_psw2()
{
	var un = $('#id_chp').val();
	var op = $('#id_old').val();
	var np = $('#id_new').val();
	var send_var = 'un='+un+'&'+'op='+op+'&'+'np='+np;
	serv_cn('ch_psw.php', send_var, s, e);
	$('#ch_psw').hide();
}
//-----------------------  L O G - O U T  -------------------------------------------------------
function out()
{
	clear_par();
	serv_cn('log_out.php', null, s_who, e);
}
//-------------------------   A S S I S T A N T     --------------------------------------------
function assist()
{
	hide_all_form(); 
	$("#ass").toggle(800);
	if($('#vn').text()=='▼') $('#vn').text('▲');
	else $('#vn').text('▼'); 
}
//-----------------------   T R A N I N G       --------------------------------
function eng_rus()
{
	hide_all_form();
	if($('#select').val() == 'all') serv_cn('all_1.php', null, s, e);
	else serv_cn('all_1df.php', null, s, e);
}
function rus_eng()
{
	hide_all_form();
	if($('#select').val() == 'all')  serv_cn('all_3.php', null, s, e);
	else serv_cn('all_3df.php', null, s, e);
}
//-------------------------------------------------
var j,i,n;
function cellindex(x) { j = x.cellIndex; }
function rowindex(x) 
{
	i = x.rowIndex;
	n = El('myTable').rows[i].cells[1].innerHTML; 
	var send_var = 'id='+n+'&j='+j;
	if((j==4) || (j==5))
	{
		if(El('myTable').rows[i].cells[j].innerHTML =='')
			serv_cn("all_2.php", send_var, s_tbl, e);
		else
			El('myTable').rows[i].cells[j].innerHTML = '';
	}	
}
function rowindex_2(x) 
{
	i = x.rowIndex;
	n = El('myTable').rows[i].cells[1].innerHTML; 
	var send_var = 'id='+n+'&j='+j;
	if(j==2)
	{
		if(El('myTable').rows[i].cells[j].innerHTML =='')
			serv_cn("all_4.php", send_var, s_tbl, e);
		else
			El('myTable').rows[i].cells[j].innerHTML = '';
	}	
}
//-----------------------------------------------------------------
var s_dz = function(r)
{
	r = r.split('||');
	var s1 = r[0]; var s2 = r[1].trim();
	if(s1[0]==']') { s1 = s1.slice(1); my_alert(s1, 'w3-red'); }
	if(s1[0]=='}') { s1 = s1.slice(1); my_alert(s1, 'w3-blue'); }
	if(s1[0]=='|') { s1 = s1.slice(1); panel(s1); }
	El('myTable').rows[i].cells[1].innerHTML=s2;
}
function dz()
{
	var n = El('myTable').rows[i].cells[1].innerHTML;
	var send_var = 'id='+n;
	serv_cn("all_6.php", send_var, s_dz, e);
}
//-------------------   S P E L L I N G       -------------------------------
var arr;
var i = 0;
function clear_f_sp()
{
	$('#num').text('');
	$('#sum').text('');
	$('#p').text('');
	$('#n').text('');
	$('#sp_2_1').val('');
	$('#sp_2_2').val('');
	$('#hint').text('');
}
var s_sp_1 = function(r)
{
	if(r[0]=='[')
	{
		arr = JSON.parse(r);
		$('#sp_2_1').val(arr.shift());
		$('#p').text(arr.shift());
		$('#n').text(arr.shift());
		$('#num').text(1);
		$('#sum').text(arr.length);
		i=0;                       // sxal kar				
	}
	else if(r[0]==']') { r = r.slice(1); my_alert(r, 'w3-red'); }
	else my_alert(r);
}
function sp_1()
{
	clear_par();
	clear_f_sp();
	if( $('#who').text().trim() == "No User")
	{
		my_alert('There is no active user. Please log in at first.', 'w3-red');
		return;
	}
	else $('#f_sp').show();
	var send_var = 'select='+$('#select').val();
	serv_cn("sp_1.php", send_var, s_sp_1, e);
}
//----------------------------
var s_sp_next = function (r)
{
	 if(r[0]=='[')
			{
				var a = JSON.parse(r);
				$('#sp_2_1').val(a[0]);
				$('#p').text(a[1]);
				$('#n').text(a[2]);
				$('#num').text(i+1);
			}
		    else if(r[0]==']') { r = r.slice(1); my_alert(r, 'w3-red'); }
		    else alert(r);
}
function sp_next()
{
	//------------------------------ clear
	El('hint').setAttribute("class", "w3-tag w3-border w3-white");// karmir kmna
	$('#hint').text('');
	$('#sp_2_2').val('');
	//-------------------------------------
	i++;
	if(i < arr.length) $('#num').text(i+1);
	else { i--; return; }
	var send_var = 'id='+arr[i]+'&select='+$('#select').val();
	serv_cn("sp_2.php", send_var, s_sp_next, e);
}
//---------------------------
var s_sp_prev = function(r)
{
	if(r[0]=='[')
			{
				var a = JSON.parse(r);
				$('#sp_2_1').val(a[0]);
				$('#p').text(a[1]);
				$('#n').text(a[2]);
				$('#num').text(i+1);
			}
		    else if(r[0]==']') { r = r.slice(1); my_alert(r, 'w3-red'); }
		    else alert(r);
}
function sp_prev()
{
	//------------------ clear
	El('hint').setAttribute("class", "w3-tag w3-border w3-white");
	$('#hint').text('');
	$('#sp_2_2').val('');
	//------------------------
	i--;
	if(i >= 0) $('#num').text(i+1);
	else { i++; return; }
	var send_var = 'id='+arr[i]+'&select='+$('#select').val();
	serv_cn("sp_2.php", send_var, s_sp_prev, e);
}
//-----------------------------      H I N T        ----------------------
var s_hush = function(r)
{
	if(r[0]==']') { r = r.slice(1); my_alert(r, 'w3-red'); }
	else $('#hint').text(r);
}
function hush()
{
	var send_var = 'id='+arr[i]+'&select='+$('#select').val();
	serv_cn("sp_3.php",send_var, s_hush, e);
}
//-------------------      C H E C K        ------------------------------
var s_checkw = function(r)
{
	var a = JSON.parse(r);
	if(r[0]=='[')
	{
		if(a[2] == 1)
		{
			El('hint').setAttribute("class", "w3-tag w3-border w3-green");
			$('#hint').text(a[0]);
			El('hint').style.color= "red";
			$('#p').text(a[1]++);
		}
		if(a[2] == 0)
		{
			El('hint').setAttribute("class", "w3-tag w3-border w3-red");
			$('#hint').text(a[0]);
			$('#n').text(a[1]--);
		}
	}
	else if(r[0]==']') { r = r.slice(1); my_alert(r, 'w3-red'); }
	else alert(r);	
}
function checkw()
{
	var send_var = 'id='+arr[i]+'&word='+$('#sp_2_2').val();
	serv_cn("sp_4.php", send_var, s_checkw, e );
}