function serv_cn(url_of_php, send_var, callback_function)
{ 
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", url_of_php, true);
				xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded;charset=UTF-8");
				xhttp.setRequestHeader("Content-length", send_var.length);
				xhttp.setRequestHeader("Connection", "close");
				xhttp.onreadystatechange = function() 
				{
					if (xhttp.readyState == 4 && xhttp.status == 200) 
						callback_function(xhttp.responseText);
				} 
				xhttp.send(send_var);
}
//------------------------------------------------------------
function my_alert (mess, color ='w3-blue')
{
			var w3_class = 'w3-container '+color;
			$('#alert').show();
			$('#message').text(mess);
			$('#al_head').attr('class', w3_class);
}
//------------------------------------------------------------
function mess()
{
			if($('#mess_text').val() == '')
				my_alert('Your text is empty.', 'w3-red');
			else 
			{
				var send_var = "t="+$('#mess_text').val();
				serv_cn ('message.php', send_var, myFunction);
			}
	$(document).ready(function(){
		//$('#mess_text').fadeTo(3000, 0.00);
		$('#mess_text').val('',3000);
	});
}
//---------------------------------------------------------
function myFunction(str) 
{ 
	str = str.trim();
	if(str[0]=='|') { str = str.slice(1); my_alert(str, 'w3-green'); }
	else if(str[0]==']') { str = str.slice(1); my_alert(str, 'w3-red'); }
	else if(str[0]=='}') { str = str.slice(1); my_alert(str, 'w3-blue'); }
	else alert(str); 
}
//--------------------------------------------------------
