<?php
session_start();
$ss = $_SESSION["login"];
$t = $_POST["t"];
if(empty($ss))
	exit("]To leave message you should login the system at first");
elseif(empty($t))
	exit("]Your text is empty!");
?> 
<?php

//$from = "noreply@tothis.mail";
$email = "robertkh@myvocabulary.dx.am";
$subject = "Message From Site";
// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
// More headers
$headers .= 'From:'.$ss . '@user.noreply' . "\r\n";

$message = "
<html>
<head>
<title>HTML email</title>
</head>
<body>
<p>" .$t."
</body>
</html>";

//mail($email, $subject, $message, "From:".$from);
mail($email, $subject, $message, $headers);
echo "|Your message have sent succesfully.";
?>