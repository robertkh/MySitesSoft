<?PHP
$u = $_POST['u'];
if(empty($u)) 
	exit;
elseif (is_numeric($u[0])) 
    exit("<strong id = 'r1' style='color:#F00'>Usernames must begin with a letter.</strong >");
elseif ((strlen($u) < 3 || strlen($u) > 18)) 
    exit("<strong id = 'r1' style='color:#F00'>3 - 16 characters please.</strong >"); 
else
{
	//---------------------------------------------------------------------------
	include_once 'conn.php';
	//---------------------------------------------------------------------------
	$sql = "SELECT * FROM users WHERE login = '$u' LIMIT 1";
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0)
		exit("<strong id = 'r1' style='color:#F00'> '$u' is taken, please try other one.</strong>");
}
echo "OK";
?>