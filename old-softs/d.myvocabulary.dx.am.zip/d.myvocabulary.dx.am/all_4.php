<?php
session_start();
$ss = $_SESSION["login"];
if(empty($ss)) exit("]There is no active user. Please log in at first!"); 
?>
<?php
$n = strip_tags(addslashes($_POST["id"]));
$t = $_POST["j"];
if( empty($n) or empty($t) ) exit("]The necessary input fild(s) has not filled!");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
$sql = "SELECT word FROM $ss WHERE id = $n";
$result = mysqli_query($conn, $sql);
$n_r = mysqli_num_rows($result);
if($n_r == 0)
    echo "]Your vocabulary is empty!";
else 
{             
    $row = mysqli_fetch_assoc($result);
    echo "<span style='color:blue'>".$row['word']."</span>";         
}
//------------------------------------------------
mysqli_close($conn);
?>