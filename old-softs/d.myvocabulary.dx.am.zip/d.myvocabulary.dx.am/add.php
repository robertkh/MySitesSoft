<?php 
session_start();
$ss = $_SESSION["login"];
if(empty($ss))
    exit("]There is no active user. Please log in at first!");
?>
<?php
$send_word = $_POST["id1"];
$send_pos = $_POST["id2"];
$send_translation = $_POST["id3"];
$send_memo = $_POST["id4"];
//$send_memo = str_replace("'","\'" , $send_memo);addslashes();stripslashes();
if(empty($send_word) or empty($send_pos))
	exit("]The necessary input fild(s) has not filled!");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
?>
<?php
$send_memo = mysqli_real_escape_string($conn, $send_memo);  // sa mi ban el avel e anum, qan 15 togy
//$send_memo=htmlspecialchars($send_memo);
$sql = "INSERT INTO $ss(word, pos, translation, df, memo) 
		VALUES ('$send_word','$send_pos', '$send_translation', '1', '$send_memo')";
if (!mysqli_query($conn, $sql)) 
	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
else
	echo "|The word has been added succesfully!";
//----------------------------------------------------------------------------
mysqli_close($conn);
?> 



<?php
// the message
//$msg = "First line of text\nSecond line of text";
// use wordwrap() if lines are longer than 70 characters
//$msg = wordwrap($msg,70);
// send email
//mail("robert.khnkoyan@gmail.com","My subject",$msg);
?> 