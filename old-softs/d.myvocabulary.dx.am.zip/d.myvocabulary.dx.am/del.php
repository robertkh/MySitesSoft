<?php
session_start();
$ss = $_SESSION["login"];
 if(empty($ss))
    exit("]There is no active user. Please log in at first!");
?>
<?php
$send_id = strip_tags($_POST["id"]);
if(empty($send_id))
	exit("]The necessary input fild(s) has not filled!");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
$sql = "DELETE FROM $ss WHERE id ='$send_id'";
if ( !mysqli_query($conn, $sql))
    echo "Error deleting record: " . mysqli_error($conn);
else
	echo "|The word has been deleted succesfully!";
//------------------------------------------------------------
mysqli_close($conn);
?>