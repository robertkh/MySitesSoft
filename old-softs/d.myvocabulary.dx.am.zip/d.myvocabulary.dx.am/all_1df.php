<?php
session_start();
$ss = $_SESSION['login'];
 if(empty($ss))
    exit("]There is no active user. Please log in at first!");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
$sql = "SELECT id, word, pos, translation, memo, df FROM $ss WHERE df='1'  order by word";
$result = mysqli_query($conn, $sql);
$cnt_of_words = mysqli_num_rows($result);
if($cnt_of_words == 0)
    echo "]Your vocabulary is empty!";
else 
{
    echo "<h2> Count of words is $cnt_of_words </h2>
            <table id ='myTable'>
                <thead>
                    <tr>
                        <th class = 'c1'><i class='fa fa-check' style='font-size:14px'></i></th>
                        <th class = 'c2'>Id#</th>
                        <th class = 'c3'>Word</th>
                        <th class = 'c4'>Pos</th>
                        <th class = 'c5'> Translation </th>
                        <th> E x a m p l e </th>
                    </tr>
                </thead>
                <tbody>";
    while($row = mysqli_fetch_assoc($result)) 
    {
        echo    "<tr onclick='rowindex(this)'>
                    <td onclick='cellindex(this)'><input type = 'checkbox' onchange = 'dz()' </td> 
                    <td onclick='cellindex(this)'> 
                    <span style='color:red'>" .$row['id']. "</span></td>
                    <td onclick='cellindex(this)'>".$row['word']."</td>
                    <td onclick='cellindex(this)'>" . $row['pos']  . "</td>
                    <td onclick='cellindex(this)'></td>";
        // sksum e f-n
                    $s1 = "<mark>" .$row['word']. "</mark>";
                    $s2 = str_replace($row['word'],$s1, $row['memo']);
        // avart
        echo        "<td onclick='cellindex(this)'></td> 
                </tr>";
    }
    echo        "</tbody>
            </table>";
} 
//------------------------------------------------
mysqli_close($conn);
?>