<?php
//if (headers_sent()) echo " ??? yes -sent<br/>";
session_start();
$ss = $_SESSION["login"];
if(empty($ss))
    exit("] There is no active user. Please log in at first!");
?>
<?php
$send_search_word = trim($_POST["n_search"]);
if(empty($send_search_word))
	exit("] Search Fild Is Empty!");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
?>
<?php
$sql = "SELECT id, word, pos, translation, memo FROM $ss where word='$send_search_word'";
$result = mysqli_query($conn, $sql);
$cnt_of_words = mysqli_num_rows($result);
echo "<h2>Count of words is $cnt_of_words</h2>";
if ($cnt_of_words > 0) 
{
    echo "<table id ='myTable'>
            <tr>
                <th class = 'c1'><i class='fa fa-check' style='font-size:14px'></i></th>
                <th class = 'c2'>Id#</th>
                <th class = 'c3'>Word</th>
                <th class = 'c4'>Pos</th>
                <th class = 'c5'>Translation</th>
                <th> E x a m p l e </th>
            </tr>";
    while($row = mysqli_fetch_assoc($result)) 
    {
        echo "<tr>";
        echo "<td><input type = 'checkbox' name = 'a' /*onclick ='if(this.checked)
        { find_row() }' */</td>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["word"] . "</td>";
        echo "<td>" . $row["pos"]  . "</td>";
        echo "<td>" . $row["translation"]. "</td>";
        // sksum e f-n
        $s1 = "<mark>". $row["word"]."</mark>";
        $s2 = str_replace($row["word"],$s1, $row["memo"]);
        // avart
        echo "<td>" . $s2 . "</td>"; 
        echo "</tr>";
    }
    echo "</table>";
}
//--------------------------------
mysqli_close($conn);
?>