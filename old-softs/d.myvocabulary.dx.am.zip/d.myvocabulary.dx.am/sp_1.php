<?php
session_start();
$ss = $_SESSION['login'];
//if(empty($ss)) exit("]There is no active user. Please log in at first"); js-um stugvum a, avelord e
?>
<?php
$f = $_POST["select"];
//if( empty($f)) exit("]The POST Is Empty. Please fill all filds."); kartses es depqy chi patahum
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
if($f == 'all')
    $sql = "SELECT translation,p,n FROM $ss LIMIT 1";
else 
     $sql = "SELECT translation,p,n FROM $ss WHERE df = '1' LIMIT 1";

$result = mysqli_query($conn, $sql);
$n_r = mysqli_num_rows($result);
if($n_r == 0) exit("]Your vocabulary is empty!");
$row = mysqli_fetch_assoc($result);
$ar = '["'.$row['translation'].'",'.$row['p'].','.$row['n'].','; // json-um ""
//------------------------------------------------
if($f == 'all')
    $sql = "SELECT id FROM $ss";
else 
    $sql = "SELECT id FROM $ss WHERE df = '1'";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result) == 0)
    exit("]Your vocabulary is empty.");
while($row = mysqli_fetch_assoc($result))
    {
        $ar .=$row['id'].=',';
    } 
echo chop($ar,",")."]";              // !!!hanum a, bayc save chi anum      
//------------------------------------------------
mysqli_close($conn);
?>