<?php
// echo getenv('REMOTE_ADDR'); kara ogtakar lini
$send_login = $_POST["login"];
$send_pass = $_POST["password"];
$send_email = $_POST["email"];
if(empty($send_login) or empty($send_pass) or empty($send_email))
	exit("]The necessary input fild(s) has not filled!");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
?>
<?php
$sql = "SELECT * FROM users WHERE login = '$send_login' LIMIT 1";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0)
	exit("] This username is taken, please try other one!");
$sql1 = "INSERT INTO users (login, password, email) 
		VALUES ('$send_login','$send_pass', '$send_email')";
if (!mysqli_query($conn, $sql1))
{
    echo "Error: " . $sql1 . "<br>" . mysqli_error($conn);
    exit();
}
else
{
	$sql_1 ="CREATE TABLE $us
	(
		id           int( 3 ) NOT NULL AUTO_INCREMENT ,
		word         varchar( 30 ) NOT NULL ,
		pos          varchar( 12 ) NOT NULL ,
		translation  varchar( 30 ) NOT NULL ,
		memo         text NOT NULL ,
		dt           timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP ,
		df           ENUM('0','1') NOT NULL DEFAULT '0',
                p            INT(3) NOT NULL DEFAULT '0' ,
                n            INT(3) NOT NULL DEFAULT '0' ,
                PRIMARY KEY ( `id` ) 
	)";
	if (!mysqli_query($conn, $sql2))
	{
    	echo "Error: " . $sql2 . "<br>" . mysqli_error($conn);
	}
}
//---------------------------------------------------------------
mysqli_close($conn);
?> 
<?php
//$from = "noreply@tothis.mail";
$email = $send_email;
$subject = "Activate Account";
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: noreply@to_this_mail' . "\r\n";

$message = "
<html>
<head>
<title>HTML email</title>
</head>
<body>
<p> Dear <u>$send_login</u> click the link below to activate account!</p>
<a href = 'http://myvocabulary.dx.am/activ.php?a_code=$send_login'> Activate now </a>
</body>
</html>";

//mail($email, $subject, $message, "From:".$from);
mail($email, $subject, $message, $headers);

echo "|Succesfully Registration! Please check your mail, you have been sent your activation link.";
?>
<?php
/*$sql = " CREATE USER '$send_login'@'localhost'  IDENTIFIED BY 'newpass'";
$sql1 = "CREATE DATABASE IF NOT EXISTS ".$send_login;
$sql2 ="CREATE TABLE ".$send_login.".table_".$send_login."
(
id           int( 3 ) NOT NULL AUTO_INCREMENT ,
word         varchar( 20 ) NOT NULL ,
pos          varchar( 8 ) NOT NULL ,
translation  varchar( 30 ) NOT NULL ,
memo         text NOT NULL ,
dt           timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP ,
PRIMARY KEY ( `id` ) 
)";
$sql3 = "GRANT ALL PRIVILEGES ON ".$send_login.".* TO '$send_login'@'localhost'";*/
//$sql3 = " GRANT ALL PRIVILEGES ON *.* TO '$send_login'@'localhost'";
?>