<?php
session_start();
$ss = $_SESSION["login"];
if(empty($ss)) 
    exit("]There is no active user. Please log in at first!");
?>
<?php
$f = $_POST["o_a_t"];
if(empty($f))
    exit("]The necessary input fild(s) has not filled!");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
?>
<?php
$sql = "SELECT id, word, pos, translation, memo, df, dt FROM $ss";
$result = mysqli_query($conn, $sql);
$date2=date_create( $f );
$cnt_of_words = 0;
while($row = mysqli_fetch_assoc($result)) 
{
    $date1=date_create( $row["dt"] );
    $diff=date_diff($date1,$date2); //d2-d1 --> data2-y mer mutqn e.
    if(($diff->format("%R%a.")<0)or ($diff->format("%R%a.")==0 and $diff->format("%R%h.")<0))
           $cnt_of_words++;
}
echo "<h1>Count of words is ".$cnt_of_words."</h1>";
//-----------------------------------------------------------------
$result = mysqli_query($conn, $sql);
if ($cnt_of_words > 0) 
{
    echo "<table id ='myTable'>
            <tr>
                <th class = 'c1'><i class='fa fa-check' style='font-size:14px'></i></th>
                <th class = 'c2'>Id#</th>
                <th class = 'c3'>Word</th>
                <th class = 'c4'>Pos</th>
                <th class = 'c5'> Translation </th>
                <th> E x a m p l e </th>
            </tr>";
    while($row = mysqli_fetch_assoc($result)) 
    {
        $date1=date_create( $row["dt"] );
        $diff=date_diff($date1,$date2);
        if(($diff->format("%R%a.")<0)or ($diff->format("%R%a.")==0 and $diff->format("%R%h.")<0))
        {
                    if($row['df'] == 0)
                        $id = "<span style='color:#0c0'>" .$row['id']. "</span>";
                    else 
                        $id = "<span style='color:red'>" .$row['id']. "</span>";
                    echo    "<tr>
                                <td class = 'c1'><input type = 'checkbox' name = 'a'> </td> 
                                <td class = 'c2'>" .$id. "</td>
                                <td>" . $row['word'] . "</td>
                                <td>" . $row['pos']  . "</td>
                                <td>" . $row["translation"]. "</td>";
                                // sksum e f-n
                                $s1 = "<mark>" .$row['word']. "</mark>";
                                $s2 = str_replace($row['word'],$s1, $row['memo']);
                                // avart
                    echo        "<td> $s2 </td> 
                            </tr>";
        }
        
    }
    echo "</table>";
} 
//-------------------------------------------
mysqli_close($conn);
?>