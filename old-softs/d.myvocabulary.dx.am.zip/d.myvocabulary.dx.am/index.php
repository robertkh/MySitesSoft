<!DOCTYPE html>
<html lang ="en-US">
<head>
	<title> Vocabulary </title>
    <meta charset = "UTF-8">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  	<script type = "text/javascript" src = "js/desktop_script.js"></script>
	<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/w3.css">
	<link rel="stylesheet" href="css/test.css">
</head>
<body class="w3-content" style="max-width:1024px" onload ="who()" id='bd'> 
	<header>
		<div class="w3-row" id="first_bar">
			<div class="w3-col w3-container" id='logo'>
				<span id = 'logo-1'> My </span> 
				<span id = 'logo-2'>Vocabulary</span>
			</div>
			<div class="w3-col w3-container w3-padding-8" style="width:10%"> 
				<input type ="text" class = 'w3-round' name ="n_search" id ="id_search" >
			</div>
			<div class='w3-rest  w3-padding-4 '>
				 <ul class="w3-navbar w3-right">
					<li><a class="w3-text-white w3-border-left w3-border-white" href="#" onclick ="vocab()">
						My Vocabulary</a></li>
					<li><a class="w3-text-white w3-border-left w3-border-white" href="#" onclick ="MacMil()">
						MacMillan</a></li>
					<li><a class="w3-text-white w3-hover-text-black w3-border-left w3-border-white" href="#" onclick ="Lingvo()">
						Lingvo</a></li>
					<li><a class="w3-text-white w3-hover-text-black w3-border-left w3-border-white" href="#" onclick ="Wiki()">
						Wikipedia</a></li>
					<li><a class="w3-text-white w3-hover-text-black w3-border-left w3-border-white" href="#" onclick ="Google()">
						Google</a></li>
				</ul>
			</div>
		</div>
		<div class="w3-row"  id="second_bar">
			<div class="w3-col w3-dropdown-hover w3-text-white" id='hmb'>
                                <a href="#"><i class="fa fa-bars"></i></a>
				<div class="w3-dropdown-content w3-border w3-animate-zoom">
					<a href ="#" onclick ="reg()">Create Account</a>
					<a href ="#" onclick ="log()">Sign In</a>
					<a href ="#" onclick ="out()">Sign Out</a>
					<a href ="#" onclick ="frg()"> Forgot Password ?</a>
					<a href ="#" onclick ="ch_psw1()"> Change Password</a>
				</div>
			</div>
			<div class="w3-col w3-padding-tiny " style="width:150px">
				<span class="w3-right" id = 'who'></span>
				<i class="fa fa-user w3-right " id='who1' style="font-size:24px"></i>
				
			</div>
			
			<div class='w3-rest'>
			 	<ul class="w3-navbar w3-text-white w3-right">
				<li><a  href ="#" onclick="assist()">
					<i class="fa fa-wrench" style="font-size:14px"></i>
					Assistant <span id = 'vn'>▼</span> </a> 
				</li>
				<li><a href ="#" onclick ="add_start()"> 
					<i class="fa fa-plus" style="font-size:14px"></i>
					Add </a>
				</li>
				<li><a href ="#" id ="del" onclick ="del()"> 
					<i class="fa fa-remove" style="font-size:14px"></i>
					Del </a>
				</li>
				<li><a href ="#" onclick ="move_index_to_buffer()"> 
					<i class="fa fa-refresh" style="font-size:14px"></i> Update</a>
				</li>
				<li><a href ="#" onclick ="add_to_df()"> 
					<i class="fa fa-star-o" style="font-size:14px"></i>
					Favorite</a>
				</li>
				</ul>
			</div>
		</div>
		
	</header>
		<div class="w3-container w3-light-green w3-center w3-large w3-padding-tiny " style = "display:none; position:absolute; width:1014px; z-index:1;" id = 'panel'>
			<i class="fa fa-check-square-o" style="color:green"></i>
			<span></span>
	  		<a href ='#' class ='cancel w3-text-white w3-hover-text-black' onclick="$('#panel').hide()">&times;</a>
		</div>
	<main id = 'main' class="w3-display-container">

	    <div id="alert" class="w3-modal">
                        <div id = 'alert_1' class="w3-modal-content w3-card-4" style="width:400px;">
                                <header class="w3-container" id='al_head'> 
                                        <span onclick="document.getElementById('alert').style.display='none'" 
                                           class="w3-closebtn w3-padding-top w3-large">&times;</span>
                                           <h4>Message from My<i>Vocabulary</i> :</h4>
                                </header>

                                <div id="message" class="w3-large w3-padding-large w3-small"></div>
                         </div>
        </div>
              
		<div id="wait" class="w3-modal" style="display:block; ">
		  	<div class="w3-modal-content w3-card-4 w3-display-middle" style="width:68px; padding:2px;" >
		    	<img src='img/wait.gif' alt='please wait...' width="64" height="64" />
		  	</div>
		</div>
                
		<div id = 'ass'>
			<nav>
				<a href = '#' onclick="eng_rus()">Eng-Rus</a>
				<a href = '#' onclick="rus_eng()">Rus-Eng</a>
				<a href = '#' onclick="sp_1()">Spelling</a>
				<select id ="select" >                            
						<option value ="all"> all </option>
						<option value ="favorite"> favorite </option>
				</select>
				<a href = '#' onclick="lookup()">LookUp</a>
				<select id ="select_2" >                            
						<option value ="all"> all </option>
						<option value ="scope"> scope </option>
						<option value ="date"> date </option>
						<option value ="diagramma"> diagramma </option>
				</select>
			</nav>
		</div>
		
		<form class="w3-container w3-card-4" id='n_w_f'>
			<a href ='#' class ='cancel' onclick="$('#n_w_f').hide()">&times;</a>
			<h2 class="w3-text-blue">New Word</h2>
			<hr/>
			<p>
				<label class="w3-text-blue"><b>WORD</b></label>
				<input class="w3-input w3-border" type="text" id ="id1">
			</p>
			<label class="w3-text-blue"><b>P O S</b></label>
			<select class="w3-select w3-border" name="option" id ="id2">
				<option value="" disabled selected>Part Of Speach</option>
				<option value ="comp"> computer </option>
				<option value ="verb"> verb </option>
				<option value ="noun"> noun</option>
				<option value ="adjective"> adjective </option>
				<option value ="adverb"> adverb </option>
				<option value ="pronoun">pronoun </option>
				<option value ="preposition"> preposition </option>
				<option value ="conjunction"> conjunction </option>
				<option value ="interjection"> interjection </option>
			</select>
			<p>      
				<label class="w3-text-blue"><b>TRANSLATION</b></label>
				<input class="w3-input w3-border" id ="id3">
			</p>
			<p>      
				<label class="w3-text-blue"><b>EXAMPLE</b></label>
				<textarea class="w3-input w3-border" id ="id4"></textarea>
			</p>
			<p class = "w3-center">
				<input type="button" value = 'Submit' class="w3-btn w3-blue " onclick ="add()" >       
			</p>
		</form>
		<form class="w3-container w3-card-4" id='u_w_f'>
			<a href ='#' class ='cancel' onclick="$('#u_w_f').hide()">&times;</a>
			<h2 class="w3-text-blue">Update Word </h2>
			<hr/>
			<p>
				<label class="w3-text-blue"><b>ID</b></label>
				<input class="w3-input w3-border" type="text" name ="id" id ="id_id">
			</p>
			<p>
				<label class="w3-text-blue"><b>WORD</b></label>
				<input class="w3-input w3-border" type="text" name ="word" id ="id_word">
			</p>
				<label class="w3-text-blue"><b>P O S</b></label>
				<select class="w3-select w3-border" name="option" id ="id_pos">
					<option value="" disabled selected>Part Of Speach</option>
					<option value ="comp"> computer </option>
					<option value ="verb"> verb </option>
					<option value ="noun"> noun</option>
					<option value ="adjective"> adjective </option>
					<option value ="adverb"> adverb </option>
					<option value ="pronoun">pronoun </option>
					<option value ="preposition"> preposition </option>
					<option value ="conjunction"> conjunction </option>
					<option value =" interjection"> interjection </option>
				</select>
			<p>      
				<label class="w3-text-blue"><b>TRANSLATION</b></label>
				<input class="w3-input w3-border" name ="trans" id ="id_trans">
			</p>
			<p>      
				<label class="w3-text-blue"><b>EXAMPLE</b></label>
				<textarea class="w3-input w3-border" name ="ex" id ="id_ex"></textarea>
			</p>
			<p class = "w3-center">
				<input type="button" value = 'Submit' class="w3-btn w3-blue " onclick ="update()">      
			</p>
		</form>
		<form class="w3-container w3-card-4" id='scope_f'>
			<a href ='#' class ='cancel' onclick="$('#scope_f').hide()">&times;</a>
			<h2 class="w3-text-blue">Scope</h2>
			<hr/>
			<p>
				<label class="w3-text-blue"><b>From</b></label>
				<input class="w3-input w3-border" type="text" name ="first" id ="id_fr">
			</p>
			<p>
				<label class="w3-text-blue"><b>Till</b></label>
				<input class="w3-input w3-border" type="text" name ="second" id ="id_to">
			</p>
	
			<p class = "w3-center">
	    		<input type="button" value = 'Submit' class="w3-btn w3-blue " onclick ="scope_2()"> 
			</p>
		</form>
		<form class="w3-container w3-card-4" id='reg_f'>
			<a href ='#' class ='cancel' onclick="$('#reg_f').hide()">&times;</a>
			<h2 class="w3-text-blue">Sign up</h2>
			<hr/>
			<p>
				<label class="w3-text-blue"><b>Full name</b></label>
				<input class="w3-input w3-border" type="text" id ="id_user2" oninput="checkun()">
			</p>
                 	<p>      
				<label class="w3-text-blue"><b>Email</b></label>
				<input class="w3-input w3-border" type="email" name="psw" id ="id_email" onblur = "checkemail()">
                                
			</p>
			<p>      
				<label class="w3-text-blue"><b>Password</b></label>
				<input class="w3-input w3-border" type="password" id ="id_psw2" oninput="checkpsw()">
			</p>
			<p class = "w3-center"> 
				<input type="button" value = 'Submit' class="w3-btn w3-blue " onclick ="create_new_user()">     
			</p>
                        <span id = "ust"></span>
                        <span id = "est"></span>
                        <span id = "pst"></span>
			<span id = "bst"></span>
		</form>			
		<form class="w3-container w3-card-4" id='log_f'>
			<a href ='#' class ='cancel' onclick="$('#log_f').hide()">&times;</a>
			<h2 class="w3-text-blue">Sign in</h2>
			<hr/>
			<p>
				<label class="w3-text-blue"><b>Full name</b></label>
				<input class="w3-input w3-border" type="text" name ="login" id ="id_user1">
			</p>
			<p>      
				<label class="w3-text-blue"><b>Password</b></label>
				<input class="w3-input w3-border" type="password" name="psw" id ="id_psw1">
			</p>
			<p class = "w3-center">    
				<input type="button"  value = 'Submit' class="w3-btn w3-blue " onclick ="log_in()">
			</p>
		</form>	
		<form class="w3-container w3-card-4" id='frg_psw'>
			<a href ='#' class ='cancel' onclick="$('#frg_psw').hide()">&times;</a>
			<h2 class="w3-text-blue">Forget Password?</h2>
			<hr/>
			<p>
				<label class="w3-text-blue"><b>Email</b></label>
				<input class="w3-input w3-border" type="email" name ="email" id ="id_email2">
			</p>
	
			<p class = "w3-center">
				<input type="button" value = 'Submit' class="w3-btn w3-blue " onclick ="em_psw()">      
			</p>
		</form>
		<form class="w3-container w3-card-4" id='ch_psw'>
			<a href ='#' class ='cancel' onclick="$('#ch_psw').hide()">&times;</a>
			<h2 class="w3-text-blue">Change Password</h2>
			<hr/>
			<p>
				<label class="w3-text-blue"><b>Username</b></label>
				<input class="w3-input w3-border" type="text" name ="login" id ="id_chp">
			</p>
			<p>      
				<label class="w3-text-blue"><b>Old Password</b></label>
				<input class="w3-input w3-border" type="password" id ="id_old">
			</p>
			<p>      
				<label class="w3-text-blue"><b>New Password</b></label>
				<input class="w3-input w3-border" type="password" id ="id_new">
			</p>
			<p class = "w3-center"> 
				<input type="button" value = 'Submit' class="w3-btn w3-blue " onclick ="ch_psw2()">      
			</p>
		</form>
		<form class="w3-container w3-card-4" id='f_sp'>
			<a href ='#' class ='cancel' onclick="$('#f_sp').hide()">&times;</a>
			<h2 class="w3-text-blue">Spelling</h2>
			<hr>
			Curr: <span class="w3-tag w3-yellow" id = 'num'></span>
			Total: <span class="w3-tag w3-yellow w3-margin-right" id = 'sum'></span>
			Right: <span class="w3-badge w3-green" id = 'p'></span>
			Wrong: <span class="w3-badge w3-red" id = 'n'></span> 
			<p>      
				<label class="w3-text-blue"><b>Rus</b></label>
				<input class="w3-input w3-border" name="first" type="text" id ="sp_2_1">
			</p>
			<p>      
				<label class="w3-text-blue"><b>Eng</b></label>
				<input class="w3-input w3-border" name="last" type="text" id ="sp_2_2">
				<span class="w3-tag w3-border w3-white" id = 'hint'></span>
			</p>

			<p class = "w3-center">
				<a href="#" class="w3-btn w3-blue" onclick ="sp_prev()" id = "l">
     		    <i class='fa fa-chevron-left' style='font-size:18px'></i>
       			 </a>
				<input type="button" value = 'Hint' class="w3-btn w3-blue " onclick ="hush()" id='hint_btn'> 
				<input type="button" value = 'Check' class="w3-btn w3-blue " onclick ="checkw()"> 
				<a href="#" class="w3-btn w3-blue" onclick ="sp_next()" id = "r">
          		<i class='fa fa-chevron-right' style='font-size:18px'></i>
        		</a>
			</p>
		</form>
		<div id='par'></div>
		<div class="w3-display-bottomright" id = 'col'>
			Would you like to study in this college?
			<input type="button" value = 'Submit' class="w3-btn w3-blue" onclick ="hide_col()">
		</div>
		
	</main>
	<footer> 
		<span class="w3-padding-left">2016 &copy;</span>   
                <span class="w3-padding-left"> Contact : <a href="mailto:robertkh@myvocabulary.dx.am?Subject=MyVocabulary" target="_top"><i class="fa fa-envelope-o"></i></a> </span>
                <a class="w3-padding-left" href="tab.html" target="_blank" style="text-decoration:none">Tutorial</a> 
        </footer>
</body>

</html>