<?php
session_start();
$ss = $_SESSION["login"];
if(empty($ss))
    exit("]There is no active user. Please log in at first!");
?>
<?php
$send_id = strip_tags($_POST["id"]);
$send_word = $_POST["word"];
$send_pos = $_POST["pos"];
$send_translation = $_POST["translation"];
$send_memo = $_POST["memo"];
$send_memo = strip_tags(addslashes($send_memo));
if(empty($send_id))
	exit("]The necessary input fild(s) has not filled!");
?>
<?php
//---------------------------------------------------------------------------
include_once 'conn.php';
//---------------------------------------------------------------------------
?>
<?php
$sql ="UPDATE $ss SET word ='$send_word',pos ='$send_pos',translation ='$send_translation', memo = '$send_memo' WHERE id ='$send_id'";
if (mysqli_query($conn, $sql)) 
   echo "|The word has been updated succesfully!";
else 
   echo "<h2>Error updating record: </h2>" . mysqli_error($conn);
//---------------------------------------------------------------------------
mysqli_close($conn);
?>