<?php
$em = $_POST['em'];
if(empty($em)) 
	exit;
elseif (!filter_var($em, FILTER_VALIDATE_EMAIL)) 
    exit("<strong id = 'r2' style='color:#F00'>Invalid email format!</strong>");
else
{
//---------------------------------------------------------------------------
	include_once 'conn.php';
//---------------------------------------------------------------------------
	$sql = "SELECT * FROM users WHERE email = '$em' LIMIT 1";
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0)
		exit("<strong id = 'r2' style='color:#F00'> is in use, please try other one.</strong>");
}
echo "OK";
?>